package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
)

const DataFolder = "./breach_data/" // folder to store uploaded data breaches KYS if you change this and dont listen to the read file 

var MaxWorkers = runtime.NumCPU() 

type SearchRequest struct {
	Email string `json:"email"`
}

type SearchResponse struct {
	Results []string `json:"results"`
	Error   string   `json:"error,omitempty"`
}

func main() {
	if _, err := os.Stat(DataFolder); os.IsNotExist(err) {
		os.Mkdir(DataFolder, 0755)
	}

	http.HandleFunc("/search", handleSearch)
	http.HandleFunc("/upload", handleUpload)

	fmt.Println("Backend server running on port 8080...")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func handleSearch(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	var req SearchRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Failed to parse request", http.StatusBadRequest)
		return
	}

	results := searchEmail(req.Email)
	resp := SearchResponse{Results: results}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

func handleUpload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	file, header, err := r.FormFile("file")
	if err != nil {
		log.Println("Failed to read file from request:", err)
		http.Error(w, "Failed to read file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	filePath := filepath.Join(DataFolder, header.Filename)
	out, err := os.Create(filePath)
	if err != nil {
		log.Println("Failed to create file on disk:", err)
		http.Error(w, "Failed to save file", http.StatusInternalServerError)
		return
	}
	defer out.Close()

	_, err = bufio.NewReader(file).WriteTo(out)
	if err != nil {
		log.Println("Failed to write file content:", err)
		http.Error(w, "Failed to save file content", http.StatusInternalServerError)
		return
	}

	log.Printf("File %s uploaded successfully\n", header.Filename)
	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "File %s uploaded successfully", header.Filename)
}

func searchEmail(email string) []string {
	files, err := os.ReadDir(DataFolder)
	if err != nil {
		log.Println("Failed to read data folder:", err)
		return nil
	}

	var wg sync.WaitGroup
	resultsChan := make(chan string, MaxWorkers)

	searchWorker := func(filePath string) {
		defer wg.Done()
		if result := searchInFile(filePath, email); result != "" {
			resultsChan <- result
		}
	}

	for _, file := range files {
		if !file.IsDir() && strings.HasSuffix(file.Name(), ".txt") {
			wg.Add(1)
			go searchWorker(filepath.Join(DataFolder, file.Name()))
		}
	}

	go func() {
		wg.Wait()
		close(resultsChan)
	}()

	var results []string
	for res := range resultsChan {
		results = append(results, res)
	}

	return results
}

func searchInFile(filePath, email string) string {
	file, err := os.Open(filePath)
	if err != nil {
		log.Println("Failed to open file:", filePath, err)
		return ""
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, email) {
			return fmt.Sprintf("Found in %s: %s", filepath.Base(filePath), line)
		}
	}

	if err := scanner.Err(); err != nil {
		log.Println("Error reading file:", filePath, err)
	}
	return ""
}
