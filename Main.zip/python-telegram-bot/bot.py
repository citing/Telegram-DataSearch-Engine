import telebot
import requests

# Bot Token
BOT_TOKEN = "YOUR BOTS TOKEN"
BACKEND_URL = "http://localhost:8080"

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def start_command(message):
    bot.reply_to(message, (
        "Welcome! Use /search <email> to find breaches.\n\n"
        "Commands:\n"
        "/start - Start the bot\n"
        "/stop - Stop the bot\n"
        "/search <email> - Search for email breaches"
    ))

@bot.message_handler(commands=['search'])
def search_command(message):
    try:
        query = message.text.split(' ', 1)[1].strip()
        if not query:
            bot.reply_to(message, "Please provide an email to search. Example: /search test@example.com")
            return

        response = requests.post(f"{BACKEND_URL}/search", json={"email": query})
        if response.status_code == 200:
            results = response.json().get("results", [])
            if results:
                formatted_results = ""
                for result in results:
                    file_name, breach_data = result.split(":", 1)
                    formatted_results += f"*Found in {file_name.strip()}:*\n`{breach_data.strip()}`\n\n"
                bot.reply_to(message, formatted_results, parse_mode="Markdown")
            else:
                bot.reply_to(message, "No breaches found for this email.")
        else:
            bot.reply_to(message, "An error occurred. Please try again.")
    except IndexError:
        bot.reply_to(message, "Usage: /search <email>")
    except Exception as e:
        bot.reply_to(message, f"An error occurred: {str(e)}")

@bot.message_handler(commands=['stop'])
def stop_command(message):
    bot.reply_to(message, "stopped use /start to restart the bot.")

@bot.message_handler(func=lambda message: True)
def default_response(message):
    bot.reply_to(message, "I don't understand that command. Use /start to see available commands.")

print("Bot is running...")
bot.polling()
